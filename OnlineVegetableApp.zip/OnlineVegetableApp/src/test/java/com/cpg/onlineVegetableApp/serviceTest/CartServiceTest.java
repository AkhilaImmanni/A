package com.cpg.onlineVegetableApp.serviceTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cpg.onlineVegetableApp.entities.Cart;
import com.cpg.onlineVegetableApp.exception.CartIdNotFoundException;
import com.cpg.onlineVegetableApp.service.ICartService;

@SpringBootTest
public class CartServiceTest {

	@Autowired
	ICartService iCartService;

	Cart cart = new Cart(1, 1, null);
	Cart cart1 = new Cart(2, 2, null);
	Cart cart2 = new Cart(3,55,null);
	
	  @Test void addCartTest() {
	  
	  assertNotNull(cart.getCartId());
	  }
	  

	  @Test void addCartTests() {
	  
	  assertNotNull(cart2.getCartId());
	  }
	  
	  @Test
	  void viewCartTest() {
	  assertEquals(1, iCartService.viewCart(cart).getCartId()); 
	  }
	  
	  @Test
	  void viewCartTest1() {
	  assertNotEquals(6, iCartService.viewCart(cart).getCartId()); 
	  }
	  
	  @Test
	  void removeAllItemsTest() throws CartIdNotFoundException {
	  iCartService.addCart(cart1);
	  Cart cart3 = iCartService.removeAllItems(cart1.getCartId());
	  assertEquals(2,cart3.getCartId()); 
	  }
	 
	  
		  
	  @Test 
	  void removeAllItemsTests() throws CartIdNotFoundException {
		  iCartService.addCart(cart1);
		  Cart cart3 = iCartService.removeAllItems(cart1.getCartId());
		  assertNotEquals(3,cart3.getCartId()); 
		  }
	 
	}
