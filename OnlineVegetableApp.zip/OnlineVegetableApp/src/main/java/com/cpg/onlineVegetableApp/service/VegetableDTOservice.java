package com.cpg.onlineVegetableApp.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpg.onlineVegetableApp.dao.VEGREPOSITORY;
import com.cpg.onlineVegetableApp.entities.VegetableDTO;

@Service
@Transactional
public class VegetableDTOservice {
	
	@Autowired
	private VEGREPOSITORY repository;


	public VegetableDTO addVegetable(VegetableDTO dto) {
		// TODO Auto-generated method stub
		return  repository.save(dto);
		
	}


}
