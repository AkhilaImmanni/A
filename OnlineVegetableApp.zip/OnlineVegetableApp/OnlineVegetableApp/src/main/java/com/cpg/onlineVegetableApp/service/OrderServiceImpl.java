package com.cpg.onlineVegetableApp.service;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cpg.onlineVegetableApp.entities.Order;

@Service
@Transactional
public class OrderServiceImpl implements IOrderService{

	@Override
	public Order addOrder(Order order) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order viewOrder(int orderid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order updateOrderDetails(Order order) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> viewAllOrders(int custid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> viewOrderList(LocalDate date) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> viewOrderList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order cancelOrder(int orderid) {
		// TODO Auto-generated method stub
		return null;
	}

}
