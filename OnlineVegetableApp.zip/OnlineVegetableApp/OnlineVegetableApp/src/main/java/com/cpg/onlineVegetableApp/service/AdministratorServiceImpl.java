package com.cpg.onlineVegetableApp.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpg.onlineVegetableApp.dao.IAdministratorRepository;
import com.cpg.onlineVegetableApp.entities.Administrator;
@Service
@Transactional
public class AdministratorServiceImpl implements IAdminService{
	
	@Autowired
	IAdministratorRepository repository;

	@Override
	public Administrator addAdmin(Administrator admin) {
		// TODO Auto-generated method stub
		try {
			Administrator admin2=repository.save(admin);
			return (admin2);
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public Administrator updateAdminDetails(Administrator admin) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Administrator removeAdmin(Administrator admin) {
		// TODO Auto-generated method stub
		try
		{
			int id=admin.getAdminId();
			Optional<Administrator> optionaladmin=repository.findById(id);
			Administrator admin2=null;
			if(optionaladmin.isPresent())
			{
				admin2=optionaladmin.get();
				repository.deleteById(id);
				return admin2;
			}
			else {
			return admin2;
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public Administrator viewAdmin(Administrator admin) {
		// TODO Auto-generated method stub
		return null;
	}

}
