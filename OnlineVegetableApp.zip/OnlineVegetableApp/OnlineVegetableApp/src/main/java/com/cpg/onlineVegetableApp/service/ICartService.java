package com.cpg.onlineVegetableApp.service;

import java.util.List;

import com.cpg.onlineVegetableApp.entities.Cart;
import com.cpg.onlineVegetableApp.entities.VegetableDTO;

public interface ICartService {
	public VegetableDTO addToCart(VegetableDTO item);
	public Cart removeVegetable(int vegId);
	public Cart increaseVegQuantity(int vegId,int quantity);
	public Cart decreseVegQuantity(int vegId,int quantity);
	public List<VegetableDTO> viewAllItems(Cart cart);
	public Cart removeAllItems(Cart cart);

}
