package com.cpg.onlineVegetableApp.service;

import com.cpg.onlineVegetableApp.entities.BillingDetails;

public interface IBillingDetailsService {
	public BillingDetails addBill(BillingDetails bill);
	public BillingDetails updateBill(BillingDetails bill);
	public BillingDetails viewBill(int id);

}
